module.exports = (baseURL, server) => {

    server.get(`${baseURL}/user`, (request, response) => {
        try { response.json(require('../data/user.json')); }
        catch (exc) { response.sendStatus(404); }
    });

    
    server.get(`${baseURL}/user/availability`, (request, response) => {
        try { response.json(true); }
        catch (exc) { response.sendStatus(404); }
    });

    server.get(`${baseURL}/user/access`, (request, response) => {
        try { 
            let mockData = require('../data/user.json');
            response.json(mockData.userAccess);
        }
        catch (exc) { response.sendStatus(404); }
    });
    
};
