module.exports = (baseURL, server) => {
    server.get(`${baseURL}/filter/data`, (request, response) => {
        try {
            let data = require('../data/master-data.json');
            response.json(data);
        } catch (exc) {
            response.sendStatus(404);
        }
    });

    server.post(`${baseURL}/filter/siteids`, (request, response) => {
        try { response.json(require('../data/siteid-list.json')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.post(`${baseURL}/filter/regions`, (request, response) => {
        try { response.json(require('../data/filter-region.jason')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.post(`${baseURL}/filter/regions/all`, (request, response) => {
        try { response.json(require('../data/filter-region.jason')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.post(`${baseURL}/filter/areas`, (request, response) => {
        try { response.json(require('../data/filter-areas.json')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.post(`${baseURL}/filter/areas/all`, (request, response) => {
        try { response.json(require('../data/filter-areas.json')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.post(`${baseURL}/filter/archetypes`, (request, response) => {
        try { response.json(require('../data/filter-archetypes.json')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.get(`${baseURL}/filter/datasource`, (request, response) => {
        try { response.json(require('../data/filter-datasource.json')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.post(`${baseURL}/filter/customer`, (request, response) => {
        try {
            let data = require('../data/customer.json');
            var customer = request.url.split('=')[1];
            // if (customer != '') {
            //     var tempData = {};
            //     var customers = data.filter(x => x.value.includes(customer));
            //     tempData = customers;
            //     response.json(tempData);
            // }
            response.json(data);
        } catch (exc) {
            response.sendStatus(404);
        }
    });
};
