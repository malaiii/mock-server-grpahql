module.exports = (baseURL, server) => {
    server.post(`${baseURL}/conversation/users`, (request, response) => {
        try {
            let mockData = require('../data/actionchat.json');
            response.json(mockData.conversationUsers);
        } catch (exc) {
            response.sendStatus(500);
        }
    });

    server.post(`${baseURL}/conversation/users/add`, (request, response) => {
        try {
            let users = [
                {
                    "name": "Binod Mahto",
                    "emailId": "binod.k@maersk.com",
                    "gender": "Male",
                    "profilePic": ""
                },
                {
                    "name": "Victor Palson",
                    "emailId": "victor.palson@maersk.com",
                    "gender": "Male",
                    "profilePic": ""
                }
            ];
            response.json(users);
        } catch (exc) {
            response.sendStatus(500);
        }
    });

    server.post(`${baseURL}/conversation/users/remove`, (request, response) => {
        try {
            response.json(true);
        } catch (exc) {
            response.sendStatus(500);
        }
    });

    server.get(`${baseURL}/conversation/summary`, (request, response) => {
        try {
            let mockData = require('../data/actionchat.json');
            response.json(mockData.conversationSummary);
        } catch (exc) {
            response.sendStatus(500);
        }
    });

    server.get(`${baseURL}/conversation/detail`, (request, response) => {
        try {
            let mockData = require('../data/actionchat.json');
            response.json(mockData.userConversationsDetail);
        } catch (exc) {
            response.sendStatus(500);
        }
    });

    server.post(`${baseURL}/action/chat/reply`, (request, response) => {
        const { message, conversationId } = request.body;
        let date_ob = new Date();
        let date = ("0" + date_ob.getDate()).slice(-2);
        let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
        let hours = date_ob.getHours();
        let minutes = date_ob.getMinutes();
        let max = 1000;
        let data = {
            messageId: Math.floor(Math.random() * max),
            message: message,
            timestamp: `${month}-${date} ${hours}:${minutes}`,
            sender: "binod.k@maersk.com",
            conversationId: conversationId
        };
        try {
            response.json(data);
        } catch (exc) {
            response.sendStatus(500);
        }
    });

    server.get(`${baseURL}/action/chat/resolve`, (request, response) => {
        try {
            response.json(true);
        } catch (exc) {
            response.sendStatus(500);
        }
    });

    //this one is for POC
    server.get(`${baseURL}/action/chat`, (request, response) => {
        try {
            let mockData = require('../data/actionchat.json');
            response.json(mockData.userConversationsDetail);
        } catch (exc) {
            response.sendStatus(500);
        }
    });

    server.post(`${baseURL}/conversation/save`, (request, response) => {
        try {
            response.json({ conversationId: 1 });
        } catch (exc) {
            response.sendStatus(500);
        }
    });
}