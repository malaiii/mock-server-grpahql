module.exports = (baseURL, server) => {
    server.get(`${baseURL}/filter/monthsyear`, (request, response) => {
        try { response.json(require('../data/default-month-year.json')); }
        catch (exc) { response.sendStatus(404); }
    });    
};
