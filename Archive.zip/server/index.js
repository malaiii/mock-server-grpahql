const path = require('path');
const port = require('../config/port');
const baseURL = require('../config/base-url');
const registerRoutes = require('../config/routes');
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const routesDirectory = path.join(__dirname, '../apis');

const server = express();
server.use(cors());
server.use(bodyParser.json());
registerRoutes(baseURL, server, routesDirectory);
server.listen(port, () => console.log(`mock-server listening on port ${port}`));
for (const stack of server._router.stack) {
    if (stack.route?.path) console.log('route ' + stack.route?.path + ' ' + JSON.stringify(stack.route?.methods));
}