module.exports = (baseURL, server) => {
    server.get(`${baseURL}/geo/country`, (request, response) => {
        try {
            var param = request.url.split('=')[1];
            let data = require('../data/countrydata.json');
            if (param != '' && param != undefined) {
                response.json(data.Revenue);
            }
            response.json(data.PDP);
        } catch (exc) {
            response.sendStatus(404);
        }
    });
    server.get(`${baseURL}/geo/state`, (request, response) => {
        try {
            let data = require('../data/statedata.json');
            response.json(data);
        } catch (exc) {
            response.sendStatus(404);
        }
    });
}
