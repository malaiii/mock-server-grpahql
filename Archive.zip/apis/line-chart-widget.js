module.exports = (baseURL, server) => {
    server.post(`${baseURL}/inbound/productivity`, (request, response) => {
        try {
            let data = require('../data/line-charts.json');
            response.json(data.inboundProductivity);
        } catch (exc) {
            response.sendStatus(404);
        }
    });

    server.post(`${baseURL}/inbound/throughput`, (request, response) => {
        try {
            let data = require('../data/line-charts.json');
            response.json(data.inboundThroughput);
        } catch (exc) {
            response.sendStatus(404);
        }
    });

    server.post(`${baseURL}/outbound/productivity`, (request, response) => {
        try {
            let data = require('../data/line-charts.json');
            response.json(data.outboundProductivity);
        } catch (exc) {
            response.sendStatus(404);
        }
    });

    server.post(`${baseURL}/outbound/throughput`, (request, response) => {
        try {
            let data = require('../data/line-charts.json');
            response.json(data.outboundThroughput);
        } catch (exc) {
            response.sendStatus(404);
        }
    });
};
