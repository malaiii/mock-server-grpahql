module.exports = (baseURL, server) => {
    server.get(`${baseURL}/kpi/metrics`, (request, response) => {
        try { response.json(require('../data/kpi-tiles-settings.json')); }
        catch (exc) { response.sendStatus(404); }
    });
    server.get(`${baseURL}/kpi/default/cogsettings`, (request, response) => {
        try { response.json(require('../data/defaultcogsettings.json')); }
        catch (exc) { response.sendStatus(404); }
    });
};
