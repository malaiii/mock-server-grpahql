module.exports = (baseURL, server) => {
  server.post(`${baseURL}/inbound/soi/summary`, (request, response) => {
    try {
      response.json(require("../data/sitesofinterests.json"));
    } catch (exc) {
      response.sendStatus(500);
    }
  });
  server.post(`${baseURL}/soi/sitedetails`, (request, response) => {
    try { response.json(require('../data/sitesofinterest-view.json')); }
    catch (exc) { response.sendStatus(404); }
});
server.post(`${baseURL}/inbound/soi/summary/negative`, (request, response) => {
  try {
    response.json(require("../data/sitesofinterests.json"));
  } catch (exc) {
    response.sendStatus(500);
  }
});
server.post(`${baseURL}/inbound/soi/summary/positive`, (request, response) => {
  try {
    response.json(require("../data/soi-positive-summary.json"));
  } catch (exc) {
    response.sendStatus(500);
  }
});
server.post(`${baseURL}/inbound/soi/summary`, (request, response) => {
  try {
    response.json(require("../data/soi-negative-summary.json"));
  } catch (exc) {
    response.sendStatus(500);
  }
});
server.get(`${baseURL}/user/level`, (request, response) => {
  try {
    response.json(require("../data/user-level.json"));
  } catch (exc) {
    response.sendStatus(500);
  }
});
server.post(`${baseURL}/aoi/details`, (request, response) => {
  try {
    response.json(require("../data/area-details.json"));
  } catch (exc) {
    response.sendStatus(500);
  }
});
server.post(`${baseURL}/roi/details`, (request, response) => {
  try {
    response.json(require("../data/region-details.json"));
  } catch (exc) {
    response.sendStatus(500);
  }
});
};
