module.exports = (baseURL, server) => {
    server.post(`${baseURL}/kpi/metricsnumbers`, (request, response) => {
        try { response.json(require('../data/kpi-details.json')); }
        catch (exc) { response.sendStatus(404); }
    });
};
