module.exports = (baseURL, server) => {
    server.post(`${baseURL}/kpi/pagezero`, (request, response) => {
        try { response.json(require('../data/page-zero.json')); }
        catch (exc) { response.sendStatus(200); }
    });
};