module.exports = (baseURL, server) => {
    server.post(`${baseURL}/forecast/metrics`, (request, response) => {
        try { response.json(require('../data/forecast-unsold-space.json')); }
        catch (exc) { response.sendStatus(404); }
    });    
};
