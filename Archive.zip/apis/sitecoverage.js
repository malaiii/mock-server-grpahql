module.exports = (baseURL, server) => {
    server.get(`${baseURL}/api/sitecoverage`, (request, response) => {
        try { response.json(require('../data/site-coverage.json')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.get(`${baseURL}/api/sitecoverage/bysource`, (request, response) => {
        try { response.json(require('../data/site-coverage-source.json')); }
        catch (exc) { response.sendStatus(404); }
    });
};
