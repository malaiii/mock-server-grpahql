module.exports = (baseURL, server) => {

    server.post(`${baseURL}/inbound/kpi/summary`, (request, response) => {
        try { response.json(require('../data/inbound-kpi-summary.json')); }
        catch (exc) { response.sendStatus(404); }
    });
    
    server.post(`${baseURL}/outbound/kpi/summary`, (request, response) => {
        try { response.json(require('../data/outbound-kpi-summary.json')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.post(`${baseURL}/inbound/kpi/accuracy`, (request, response) => {
        try { response.json(require('../data/inbound-accuracy.json')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.post(`${baseURL}/outbound/kpi/otif`, (request, response) => {
        try { response.json(require('../data/outbound-accuracy.json')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.post(`${baseURL}/inventory/kpi/summary`, (request, response) => {
        try { response.json(require('../data/inventory-kpi-summary.json')); }
        catch (exc) { response.sendStatus(404); }
    });

    server.post(`${baseURL}/kpi/insight`, (request, response) => {
        try { response.json(require('../data/kpi-insights.json')); }
        catch (exc) { response.sendStatus(404); }
    });
};
