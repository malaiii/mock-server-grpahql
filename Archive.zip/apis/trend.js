module.exports = (baseURL, server) => {
    server.get(`${baseURL}/inbound/trend/throughput`, (request, response) => {
        try {
            let data = require('../data/inbound-trend-throughput.json');
            response.json(data);
        } catch (exc) {
            response.sendStatus(404);
        }
    });

    server.get(`${baseURL}/inbound/trend/productivity`, (request, response) => {
        try {
            let data = require('../data/inbound-trend-productivity.json');
            response.json(data);
        } catch (exc) {
            response.sendStatus(404);
        }
    });

    server.get(`${baseURL}/outbound/trend/throughput`, (request, response) => {
        try {
            let data = require('../data/inbound-trend-throughput.json');
            response.json(data);
        } catch (exc) {
            response.sendStatus(404);
        }
    });

    server.get(`${baseURL}/outbound/trend/productivity`, (request, response) => {
        try {
            let data = require('../data/inbound-trend-productivity.json');
            response.json(data);
        } catch (exc) {
            response.sendStatus(404);
        }
    });

    server.get(`${baseURL}/outbound/trend/productivity`, (request, response) => {
        try {
            let data = require('../data/Metrics-trend.json');
            response.json(data);
        } catch (exc) {
            response.sendStatus(404);
        }
    });
};