/* eslint-disable */

const fs = require('fs');
const path = require('path');

module.exports = (baseURL, server, routesDirectory) => {
    const files = fs.readdirSync(routesDirectory);
    
    files.forEach((filePath) => { 
        const controller = require(path.join(routesDirectory, filePath));
        controller(baseURL, server); 
    });
};
