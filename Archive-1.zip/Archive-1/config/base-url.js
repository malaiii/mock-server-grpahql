/* eslint-disable */

module.exports = '/mock/api';