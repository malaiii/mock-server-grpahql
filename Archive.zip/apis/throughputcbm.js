module.exports = (baseURL, server) => {

    server.get(`${baseURL}/throughputcbm/kpi/summary`, (request, response) => {
        try { response.json(require('../data/throughput-cbm.json')); }
        catch (exc) { response.sendStatus(404); }
    });
    server.get(`${baseURL}/matricstrends/kpi/summary`, (request, response) => {
        try { response.json(require('../data/matrics-trend-kpi.json')); }
        catch (exc) { response.sendStatus(404); }
    });
  
};
