module.exports = (baseURL, server) => {
  server.post(`${baseURL}/dq/lnscube/customer`, (request, response) => {
    let mockData = require('../data/dqsitedata.json');
    response.json(mockData.lnscubecustomer);
  });




  server.post(`${baseURL}/dq/volumetric/coverage`, (request, response) => {
    let mockData = require('../data/dqsitedata.json');
    response.json(mockData.volcoveragedata);
  });




  server.post(`${baseURL}/dq/volumetric/customer/mapping`, (request, response) => {
    let mockData = require('../data/dqsitedata.json');
    response.json(mockData.wmscustomermapdata);
  });



  server.post(`${baseURL}/dq/volumetric/details`, (request, response) => {
    try {
      response.json(require("../data/volumetric-detailed-view.json"));
    } catch (exc) {
      response.sendStatus(500);
    }
  });


  server.post(`${baseURL}/dq/site/overview`, (request, response) => {
    try {
      response.json(require("../data/sites-overview-table-data.json"));
    } catch (exc) {
      response.sendStatus(500);
    }
  });

  server.post(`${baseURL}/dq/site/data/compliance`, (request, response) => {
    let mockData = require('../data/dqsitedata.json');
    response.json(mockData.complianceData);
  });

  server.post(`${baseURL}/dq/site/data/quality`, (request, response) => {
    let mockData = require('../data/dqsitedata.json');
    response.json(mockData.dataQuality);
  });

  server.post(`${baseURL}/dq/site/processevent/data`, (request, response) => {
    let mockData = require('../data/dqsitedata.json');
    response.json(mockData.processEventData);
  });

  server.get(`${baseURL}/dq/customer/mapping`, (request, response) => {
    let mockData = require('../data/dqsitedata.json');
    response.json(mockData.sameCustomerMatchMapping);
  });

};