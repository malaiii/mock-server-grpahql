/* eslint-disable */

const port = require('./port');
const baseURL = require('./base-url');
const routes = require('./routes');

module.exports = {
    port,
    baseURL,
    routes,
};
