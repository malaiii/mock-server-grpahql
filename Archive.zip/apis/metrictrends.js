module.exports = (baseURL, server) => {
    server.post(`${baseURL}/kpi/metrics`, (request, response) => {
        try {
            let data = require('../data/metricstrends.json');
            response.json(data.trendsCategory);
        } catch (exc) {
            response.sendStatus(404);
        }
    });

    server.post(`${baseURL}/kpi/metricstrends`, (request, response) => {
        try {
            let data = require('../data/metrics-trends.json');
            response.json(data.metricTrendsData);
        } catch (exc) {
            response.sendStatus(404);
        }
    });
}