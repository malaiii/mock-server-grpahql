module.exports = (baseURL, server) => {
    server.get(`${baseURL}/Category/chart/details`, (request, response) => {
        response.json(require('../data/chartdata.json'));
    });
};
